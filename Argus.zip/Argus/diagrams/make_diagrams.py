#!/usr/bin/env python3.11
"""Generate JPEG visualizations of the Argus algorithm.

Pure matplotlib box-and-arrow diagrams (no external data needed). Run:
    python3.11 diagrams/make_diagrams.py
Writes 01..04 *.jpg into diagrams/.
"""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = Path(__file__).parent
plt.rcParams["font.family"] = "DejaVu Sans"

# palette
C = {
    "entry":  "#1f2a44",   # dark navy
    "data":   "#2563eb",   # blue
    "pipe":   "#0e7490",   # teal
    "track":  "#7c3aed",   # purple
    "report": "#b45309",   # amber
    "out":    "#15803d",   # green
    "stop":   "#b91c1c",   # red
    "cache":  "#be185d",   # pink
    "muted":  "#64748b",   # slate
    "bg":     "#f1f5f9",
}


def box(ax, x, y, w, h, title, lines, fc, tc="white", fs_title=12, fs_body=9.5,
        mono=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
                                linewidth=1.4, edgecolor="white", facecolor=fc, zorder=2))
    ax.text(x + w / 2, y + h - 0.30, title, ha="center", va="top",
            color=tc, fontsize=fs_title, fontweight="bold", zorder=3)
    fam = "monospace" if mono else "DejaVu Sans"
    ax.text(x + w / 2, y + h - 0.78, "\n".join(lines), ha="center", va="top",
            color=tc, fontsize=fs_body, family=fam, linespacing=1.4, zorder=3)


def arrow(ax, p0, p1, label="", color="#334155", rad=0.0, ls="-", fs=8.6,
          lx=0.0, ly=0.0):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=16,
                 linewidth=1.6, color=color, connectionstyle=f"arc3,rad={rad}",
                 linestyle=ls, zorder=1))
    if label:
        mx, my = (p0[0] + p1[0]) / 2 + lx, (p0[1] + p1[1]) / 2 + ly
        ax.text(mx, my, label, ha="center", va="center", fontsize=fs,
                color="#0f172a", style="italic",
                bbox=dict(boxstyle="round,pad=0.18", fc="white", ec="none", alpha=0.85),
                zorder=4)


def canvas(w=14, h=9, title=""):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, 16); ax.set_ylim(0, 10)
    ax.axis("off")
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")
    if title:
        ax.text(0.15, 9.72, title, ha="left", va="top", fontsize=17,
                fontweight="bold", color=C["entry"])
    return fig, ax


def save(fig, name):
    fig.savefig(OUT / name, dpi=150, format="jpg",
                bbox_inches="tight", pil_kwargs={"quality": 92})
    plt.close(fig)
    print("wrote", OUT / name)


# ───────────────────────────────────────────────────────────────────
# 1. ARCHITECTURE — file-level data flow
# ───────────────────────────────────────────────────────────────────
def fig_architecture():
    fig, ax = canvas(title="Argus — поток данных по файлам (путь инвесторского отчёта)")

    box(ax, 0.4, 7.6, 4.0, 1.7, "make_investor_report.py",
        ["ENTRY POINT / CLI", "build_config(args)", "clean_old_reports()", "цикл по задачам"],
        C["entry"], mono=False)

    box(ax, 0.4, 4.9, 4.0, 1.9, "simulation/dataset.py",
        ["generate_dataset(cfg)", "полосы · сложность", "est_complexity (шум)",
         "повторы · циклы · prefix"], C["data"])

    box(ax, 6.0, 4.7, 5.4, 2.5, "core/pipeline.py", [
        "process_tracked(task, responder)",
        "1 STOP  2 CACHE  3 COMPRESS",
        "4 ROUTE  5 GENERATE",
        "→ зовёт responder (mock/live)"], C["pipe"])

    box(ax, 12.6, 7.4, 3.1, 1.9, "responder", [
        "mock: детерм.", "live: Claude API", "messages.create()",
        "→ токены, текст"], C["muted"], fs_body=9)

    box(ax, 6.2, 1.9, 5.0, 1.9, "core/tracking.py", [
        "TrackedCall.create(...)", "baseline_cost vs actual_cost",
        "savings_components() → 6 слоёв"], C["track"])

    # helpers used by pipeline
    box(ax, 0.4, 1.9, 4.2, 2.4, "хелперы пайплайна", [
        "core/compression.py  (сжатие)",
        "core/sprt.py  (обрыв циклов)",
        "core/cache.py  (кэш-учёт)",
        "ROUTING_TIERS  (роутинг)"], C["muted"], fs_title=11, fs_body=8.8)

    box(ax, 12.4, 3.6, 3.3, 2.7, "eval/investor_report.py", [
        "generate_investor_", "  report(calls,", "  manifest)",
        "4 сценария · водопад",
        "каскад · графики"], C["report"], fs_body=9)

    box(ax, 12.2, 0.4, 3.7, 2.5, "reports/investor_<ts>/", [
        "investor_report.html",
        "data/calls.jsonl",
        "data/comparisons/",
        "  call_NNN.json",
        "data/dataset_manifest"], C["out"], fs_title=10.5, fs_body=8.8, mono=True)

    arrow(ax, (2.4, 7.6), (2.4, 6.85), "cfg")
    arrow(ax, (4.4, 5.9), (6.0, 5.9), "tasks[] + manifest", ly=0.28)
    arrow(ax, (4.4, 8.4), (12.6, 8.35), "responder выбран", color=C["muted"], rad=-0.12)
    arrow(ax, (11.4, 6.2), (12.6, 7.5), "вызов модели", rad=0.15, fs=8)
    arrow(ax, (12.6, 7.7), (11.4, 6.4), "ответ", rad=0.15, color=C["pipe"], fs=8)
    arrow(ax, (8.7, 4.7), (8.7, 3.8), "1 TrackedCall / задача")
    arrow(ax, (11.2, 2.85), (12.4, 4.0), "calls[]", rad=-0.2)
    arrow(ax, (4.6, 4.0), (6.2, 3.3), "compress/stop/route", color=C["muted"],
          rad=-0.1, fs=7.8)
    arrow(ax, (14.0, 3.6), (14.0, 2.9), "пишет")

    ax.text(0.15, 0.15, "Детерминированный путь (process_tracked): роутинг по тирам, "
            "сжатие по правилам, кэш по точному совпадению промпта. "
            "Полный ML-путь pre_call/post_call (обучаемый роутер, faiss, MinHash) в отчёте не используется.",
            fontsize=8.2, color=C["muted"], style="italic")
    save(fig, "01_architecture.jpg")


# ───────────────────────────────────────────────────────────────────
# 2. PER-REQUEST PIPELINE — 5 stages + short-circuits
# ───────────────────────────────────────────────────────────────────
def fig_pipeline():
    fig, ax = canvas(title="Argus — путь одного запроса через process_tracked()  (core/pipeline.py)")

    box(ax, 0.3, 3.3, 2.9, 2.1, "TASK (вход)", [
        "conversation", "complexity", "est_complexity", "prefix · batch"],
        C["data"], fs_title=12, fs_body=8.8)

    arrow(ax, (1.75, 5.4), (4.4, 7.7), "render() → стадия 1", color=C["muted"],
          rad=0.18, fs=8)

    # stage 1 STOP
    box(ax, 3.5, 7.7, 3.0, 1.6, "1 · STOP?", [
        "is_loop → SPRT", "обрывает цикл", "actual=0  model=cache"], C["stop"], fs_body=8.8)
    # stage 2 CACHE
    box(ax, 3.5, 5.8, 3.0, 1.5, "2 · CACHE?", [
        "точный повтор?", "ответ из кэша $0", "model=cache"], C["cache"], fs_body=8.8)
    # main spine
    box(ax, 7.3, 5.6, 2.7, 1.7, "3 · COMPRESS", [
        "правила, без LLM", "history → саммари",
        "вопрос дословно"], C["pipe"], fs_body=8.6)
    box(ax, 10.5, 5.6, 2.7, 1.7, "4 · ROUTE", [
        "complexity→model", "est_cx→est_model", "<.33 H <.70 S else O"],
        C["pipe"], fs_body=8.4)
    box(ax, 13.4, 5.6, 2.4, 1.7, "5 · GENERATE", [
        "responder()", "+ prefix-кэш", "+ batch ×0.5"], C["pipe"], fs_body=8.6)

    box(ax, 10.7, 2.0, 4.8, 1.9, "TrackedCall (core/tracking.py)", [
        "baseline_cost vs actual_cost",
        "savings_components(): 6 слоёв",
        "→ data/comparisons/call_NNN.json"], C["track"], fs_body=9)

    # flow arrows along spine
    arrow(ax, (5.0, 5.8), (5.0, 5.0), "нет", color=C["cache"], fs=8)  # cache no -> down
    arrow(ax, (5.0, 7.7), (5.0, 7.3), "нет", color=C["stop"], fs=8)
    arrow(ax, (6.5, 6.55), (7.3, 6.45), "обычный путь", fs=8)
    arrow(ax, (10.0, 6.45), (10.5, 6.45))
    arrow(ax, (13.2, 6.45), (13.4, 6.45))
    arrow(ax, (14.6, 5.6), (13.1, 3.9), "учёт", rad=-0.2)

    # short-circuit exits
    box(ax, 0.3, 7.8, 2.7, 1.4, "ВЫХОД: STOP", ["вся экономия", "→ слой STOP"],
        C["stop"], fs_title=11, fs_body=8.6)
    box(ax, 0.3, 6.0, 2.7, 1.3, "ВЫХОД: CACHE", ["вся экономия", "→ слой CACHE"],
        C["cache"], fs_title=11, fs_body=8.6)
    arrow(ax, (3.5, 8.5), (3.0, 8.5), "да", color=C["stop"], fs=8.5)
    arrow(ax, (3.5, 6.5), (3.0, 6.55), "да", color=C["cache"], fs=8.5)

    ax.text(0.15, 0.2, "Стадии 1–2 «коротят» путь: если запрос — повтор или зацикленный агент, "
            "модель не вызывается вообще, вся экономия идёт в один слой. "
            "Иначе запрос идёт по основному хребту 3→4→5.", fontsize=8.4,
            color=C["muted"], style="italic")
    save(fig, "02_pipeline.jpg")


# ───────────────────────────────────────────────────────────────────
# 3. COST ACCOUNTING — baseline vs actual + 6-bucket decomposition
# ───────────────────────────────────────────────────────────────────
def fig_accounting():
    fig, ax = plt.subplots(figsize=(14, 8))
    fig.patch.set_facecolor("white"); ax.set_facecolor("white")
    ax.set_xlim(0, 16); ax.set_ylim(0, 10); ax.axis("off")
    ax.text(0.15, 9.7, "Argus — двойная бухгалтерия одного вызова  (core/tracking.py)",
            ha="left", va="top", fontsize=17, fontweight="bold", color=C["entry"])

    # baseline bar (left)
    bx, bw = 1.2, 2.2
    base_h = 6.0
    ax.add_patch(FancyBboxPatch((bx, 1.6), bw, base_h, boxstyle="round,pad=0.02,rounding_size=0.05",
                 fc="#cbd5e1", ec="#475569", lw=1.4))
    ax.text(bx + bw / 2, 1.6 + base_h + 0.25, "BASELINE", ha="center", fontweight="bold",
            fontsize=12, color=C["entry"])
    ax.text(bx + bw / 2, 1.6 + base_h / 2 + 0.3, "Sonnet\n× полный\nнеподрезанный\nпромпт",
            ha="center", va="center", fontsize=10, color="#1e293b")
    ax.text(bx + bw / 2, 1.25, "cost_of(Sonnet,\n full_in, out)", ha="center", va="top",
            fontsize=8.5, family="monospace", color=C["muted"])

    # stacked savings + actual (right)
    sx, sw = 6.4, 2.2
    segs = [
        ("COMPRESS", 1.15, C["pipe"],   "меньше входных\nтокенов × rate(Sonnet)"),
        ("ROUTE",    1.55, C["data"],   "Sonnet → дешёвая\nмодель (list price)"),
        ("PREFIX",   0.85, C["track"],  "кэш-префикс ×0.9\nскидка"),
        ("BATCH",    0.55, C["report"], "остаток ×0.5\n(Batch API)"),
    ]
    y = 1.6
    act_h = 1.9
    ax.add_patch(FancyBboxPatch((sx, y), sw, act_h, boxstyle="round,pad=0.02,rounding_size=0.05",
                 fc="#15803d", ec="white", lw=1.2))
    ax.text(sx + sw / 2, y + act_h / 2, "ACTUAL\ncost", ha="center", va="center",
            color="white", fontweight="bold", fontsize=11)
    y += act_h
    for name, h, c, note in segs:
        ax.add_patch(FancyBboxPatch((sx, y), sw, h, boxstyle="round,pad=0.01,rounding_size=0.04",
                     fc=c, ec="white", lw=1.2))
        ax.text(sx + sw / 2, y + h / 2, name, ha="center", va="center",
                color="white", fontweight="bold", fontsize=10)
        ax.text(sx + sw + 0.25, y + h / 2, note, ha="left", va="center",
                fontsize=8.4, color="#1e293b")
        y += h
    ax.text(sx + sw / 2, y + 0.25, "ACTUAL + ЭКОНОМИЯ", ha="center", fontweight="bold",
            fontsize=12, color=C["entry"])

    # equality brace
    arrow(ax, (3.4, 7.6), (6.4, 7.6), "", color=C["muted"], rad=-0.25)
    ax.text(4.9, 8.25, "одна высота\n(равны)", ha="center", fontsize=9,
            color=C["muted"], style="italic")

    # invariant box
    ax.add_patch(FancyBboxPatch((1.0, 0.15), 14.0, 0.95,
                 boxstyle="round,pad=0.02,rounding_size=0.05", fc=C["bg"], ec="#94a3b8", lw=1.2))
    ax.text(8.0, 0.62, "ИНВАРИАНТ:  baseline_cost − actual_cost  =  COMPRESS + ROUTE + PREFIX + BATCH  "
            "( + CACHE/STOP если вызова не было )   —   сходится до ~1e-17",
            ha="center", va="center", fontsize=10.5, fontweight="bold", color=C["entry"])

    # cache/stop note
    ax.add_patch(FancyBboxPatch((11.6, 5.0), 3.7, 3.3, boxstyle="round,pad=0.02,rounding_size=0.06",
                 fc="#fdf2f8", ec=C["cache"], lw=1.3))
    ax.text(13.45, 8.05, "ЕСЛИ ВЫЗОВА НЕ БЫЛО", ha="center", fontweight="bold",
            fontsize=10.5, color=C["cache"])
    ax.text(13.45, 7.5, "CACHE (повтор) или\nSTOP (цикл):\n\nactual_cost = 0\n\nВСЯ экономия\nв один слой,\nостальные = 0",
            ha="center", va="top", fontsize=9.2, color="#831843", linespacing=1.4)

    save(fig, "03_accounting.jpg")


# ───────────────────────────────────────────────────────────────────
# 4. FOUR SCENARIOS + CASCADE
# ───────────────────────────────────────────────────────────────────
def fig_scenarios():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 7.5),
                                   gridspec_kw={"width_ratios": [1.35, 1]})
    fig.patch.set_facecolor("white")
    fig.suptitle("Argus — четыре сценария сравнения  +  панель каскада  (eval/investor_report.py)",
                 fontsize=15.5, fontweight="bold", color=C["entry"], y=0.99)

    # left: 4 scenarios (illustrative numbers from the 70-task live run)
    labels = ["flat-Opus\n(всё на Opus)", "flat-Sonnet\n(всё на Sonnet)",
              "quality-matched\n(оракул роутинга)", "ARGUS\n(реальный)"]
    vals = [4.46, 0.89, 1.31, 0.51]
    cols = ["#b91c1c", "#64748b", "#b45309", "#15803d"]
    bars = ax1.bar(labels, vals, color=cols, edgecolor="white", width=0.66, zorder=3)
    for b, v in zip(bars, vals):
        ax1.text(b.get_x() + b.get_width() / 2, v + 0.08, f"${v:.2f}",
                 ha="center", fontweight="bold", fontsize=11)
    ax1.set_ylabel("стоимость воркло́да, $", fontsize=11)
    ax1.set_ylim(0, 5.2)
    ax1.grid(axis="y", alpha=0.25, zorder=0)
    ax1.set_title("70-задачный live: −89% vs frontier · −61% pure efficiency",
                  fontsize=11, color=C["muted"])
    # annotate the two deltas
    ax1.annotate("", xy=(3, 0.51), xytext=(0, 4.46),
                 arrowprops=dict(arrowstyle="<->", color="#b91c1c", lw=1.6))
    ax1.text(1.5, 3.0, "−89%\nvs flat-Opus", color="#b91c1c", fontsize=10,
             fontweight="bold", ha="center")
    ax1.annotate("", xy=(3, 0.51), xytext=(2, 1.31),
                 arrowprops=dict(arrowstyle="<->", color="#b45309", lw=1.6))
    ax1.text(2.62, 0.95, "−61%\nefficiency", color="#b45309", fontsize=9.5,
             fontweight="bold", ha="center")

    # right: cascade naive vs argus (cost + quality)
    ax2.set_title("Каскад: наивный роутер vs Argus", fontsize=11.5, color=C["entry"])
    x = [0, 1]
    cost = [0.99, 0.95]
    qual = [0.922, 0.930]
    b1 = ax2.bar([0, 1], cost, width=0.5, color=["#64748b", "#15803d"],
                 edgecolor="white", zorder=3)
    ax2.set_xticks([0, 1]); ax2.set_xticklabels(["naive\n(est_model)", "Argus\n(required_model)"])
    ax2.set_ylabel("стоимость, $", fontsize=10.5)
    ax2.set_ylim(0, 1.25)
    for b, c, q in zip(b1, cost, qual):
        ax2.text(b.get_x() + b.get_width() / 2, c + 0.02, f"${c:.2f}",
                 ha="center", fontweight="bold", fontsize=10.5)
        ax2.text(b.get_x() + b.get_width() / 2, 0.05, f"q={q:.3f}",
                 ha="center", color="white", fontweight="bold", fontsize=10)
    ax2.grid(axis="y", alpha=0.25, zorder=0)
    ax2.text(0.5, 1.13, "Argus дешевле И качественнее:\n17% запросов наивный роутер шлёт не туда",
             ha="center", fontsize=9.2, color=C["muted"], style="italic")

    fig.tight_layout(rect=[0, 0.03, 1, 0.95])
    fig.text(0.5, 0.005,
             "ROUTING = flat_opus − quality_matched   ·   эффективность = quality_matched − argus   "
             "(раскладывается в COMPRESS/PREFIX/CACHE/BATCH/STOP)",
             ha="center", fontsize=9, color=C["muted"], style="italic")
    fig.savefig(OUT / "04_scenarios.jpg", dpi=150, format="jpg",
                pil_kwargs={"quality": 92})
    plt.close(fig)
    print("wrote", OUT / "04_scenarios.jpg")


if __name__ == "__main__":
    fig_architecture()
    fig_pipeline()
    fig_accounting()
    fig_scenarios()
    print("done")
